package com.example.med;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MedApplicationTests {

	@Test
	void contextLoads() {
	}

}
